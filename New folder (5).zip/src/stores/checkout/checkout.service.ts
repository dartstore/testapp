import {
  BadRequestException,
  ConflictException,
  Injectable,
  Logger,
  NotFoundException,
} from '@nestjs/common'
import { randomUUID } from 'crypto'
import { Prisma } from '@prisma/client'
import type {
  Mode,
  OrderStatus,
  PaymentAttemptStatus,
  PaymentMethodKey,
} from '@prisma/client'
import { PrismaService } from '../../prisma/prisma.service'
import { OutboxService } from '../../common/messaging/outbox.service'
import { LedgerService } from '../../ledger/ledger.service'
import { offlineCommitment } from '../../ledger/posting-rules'
import { money, parseDecimal, toDecimalString } from '../../common/money/money.util'
import type { Money } from '../../common/money/money.types'
import { IdempotencyService } from '../../common/idempotency/idempotency.service'
import { fingerprintRequest } from '../../common/idempotency/idempotency.types'
import {
  IdReservationService,
  PAYMENT_INTENTS_TABLE,
} from '../../common/ids/id-reservation.service'
import { PaymentAccountService } from '../payments/payment-account.service'
import { ProviderRegistry } from '../payments/gateways/provider-registry.service'
import { PaymentFactApplier } from '../payments/facts/payment-fact.applier'
import { CreateCheckoutDto } from './dto/create-checkout.dto'
import {
  ProviderError,
  buildFactDedupeKey,
  nextActionKindName,
  nextActionPayload,
  pspIdempotencyKey,
  type InitializeResult,
  type NextAction,
  type ObservedFact,
} from '../payments/gateways/provider.types'

/** How long a checkout, and the stock it holds, stays alive. */
const CHECKOUT_TTL_MINUTES = 30

/** Commitment kinds this phase can honour. Gateways arrive in Phase 2. */
const SUPPORTED_COMMITMENTS = ['promise_accepted', 'awaiting_offline_settlement']

/** Idempotency scope for storefront checkout. */
const CHECKOUT_SCOPE = 'checkout.create'

/** Account states a customer may pay against. Mirrors listPaymentMethods. */
const USABLE_ACCOUNT_STATUSES: readonly string[] = ['active', 'verifying']

interface ResolvedLine {
  variantId: bigint
  productId: bigint
  title: string
  variantTitle: string | null
  imageUrl: string | null
  unitPrice: Money
  quantity: number
  trackInventory: boolean
  continueSelling: boolean
  inventoryQty: number
}

@Injectable()
export class CheckoutService {
  private readonly logger = new Logger(CheckoutService.name)

  constructor(
    private readonly prisma: PrismaService,
    private readonly ledger: LedgerService,
    private readonly outbox: OutboxService,
    private readonly accounts: PaymentAccountService,
    private readonly idempotency: IdempotencyService,
    private readonly ids: IdReservationService,
    private readonly providers: ProviderRegistry,
    private readonly applier: PaymentFactApplier,
  ) {}

  /**
   * Payment methods a shopper can pick, for one storefront.
   *
   * Only enabled offerings on active accounts, ordered by the merchant's
   * chosen position.
   */
  async listPaymentMethods(slug: string, mode: Mode = 'live') {
    const store = await this.findStore(slug)

    const offerings = await this.prisma.paymentMethodOffering.findMany({
      where: { store_id: store.id, mode, enabled: true },
      orderBy: { position: 'asc' },
    })

    if (offerings.length === 0) return []

    const accounts = await this.prisma.paymentAccount.findMany({
      where: {
        store_id: store.id,
        mode,
        status: { in: ['active', 'verifying'] },
      },
    })
    const byId = new Map(accounts.map((a) => [a.id.toString(), a]))

    return offerings
      .filter((o) => byId.has(o.account_id.toString()))
      .map((o) => ({
        id: o.id.toString(),
        method: o.method,
        gateway: byId.get(o.account_id.toString())?.gateway,
        name_ar: o.display_name_ar,
        name_en: o.display_name_en,
        commitment_kind: o.commitment_kind,
        position: o.position,
      }))
  }

  /**
   * Creates a checkout, commits it, and produces the order.
   *
   * Single-shot on purpose: the storefront posts a complete cart and
   * expects an order back. Prices are always recomputed server-side.
   *
   * Note this deviates from the outbox-consumer design for order
   * creation: the order is written inside the same transaction so the
   * response can carry it. The outbox event is still emitted, for
   * downstream consumers only (notifications, analytics).
   */
  async createAndCommit(
    slug: string,
    dto: CreateCheckoutDto,
    mode: Mode = 'live',
    idempotencyKey?: string,
  ) {
    const store = await this.findStore(slug)

    // Without this, a double-tapped Place Order button produces two
    // orders, two ledger entries and two inventory decrements. The
    // interceptor cannot be reused here: it needs a store in the tenant
    // context, and storefront routes have no ActiveStoreGuard, so the
    // store is only known after the slug is resolved.
    if (!idempotencyKey) {
      return this.commit(store, dto, mode)
    }

    const claim = await this.idempotency.claim({
      storeId: store.id,
      mode,
      scope: CHECKOUT_SCOPE,
      idempotencyKey,
      fingerprint: fingerprintRequest({
        method: 'POST',
        path: `/storefront/${slug}/checkout`,
        body: dto as unknown as Record<string, unknown>,
      }),
      ttlSeconds: this.idempotency.defaultTtlSeconds,
      leaseSeconds: this.idempotency.defaultLeaseSeconds,
    })

    if (claim.outcome === 'conflict') {
      throw new ConflictException(claim.detail)
    }

    if (claim.outcome === 'in_flight') {
      throw new ConflictException(
        'This order is already being placed. Please wait a moment.',
      )
    }

    if (claim.outcome === 'replay') {
      return claim.body as Awaited<ReturnType<CheckoutService['commit']>>
    }

    try {
      const response = await this.commit(store, dto, mode)
      await this.idempotency.complete(claim.recordId, store.id, 201, response)
      return response
    } catch (error) {
      await this.idempotency
        .fail(claim.recordId, store.id)
        .catch(() => undefined)
      throw error
    }
  }

  /** The actual commit. Split out so idempotency can wrap it. */
  private async commit(
    store: { id: bigint; currency: string },
    dto: CreateCheckoutDto,
    mode: Mode,
  ) {
    const currency = (store.currency || 'USD').toUpperCase()

    const offering = await this.prisma.paymentMethodOffering.findFirst({
      where: {
        id: BigInt(dto.payment_offering_id),
        store_id: store.id,
        mode,
        enabled: true,
      },
    })

    if (!offering) {
      throw new BadRequestException('Selected payment method is not available.')
    }

    if (!SUPPORTED_COMMITMENTS.includes(offering.commitment_kind)) {
      throw new BadRequestException(
        'Online payment is not enabled yet. Choose cash on delivery or bank transfer.',
      )
    }

    const account = await this.prisma.paymentAccount.findFirst({
      where: { id: offering.account_id, store_id: store.id, mode },
    })

    // Must match what listPaymentMethods advertises, or a customer could
    // commit against a draft or errored account by posting its offering id.
    if (!account || !USABLE_ACCOUNT_STATUSES.includes(account.status)) {
      throw new BadRequestException('Selected payment method is not available.')
    }

    const lines = await this.resolveLines(store.id, currency, dto)
    const subtotalMinor = lines.reduce(
      (acc, l) => acc + l.unitPrice.amountMinor * BigInt(l.quantity),
      0n,
    )

    if (subtotalMinor <= 0n) {
      throw new BadRequestException('Cart total must be greater than zero.')
    }

    const now = new Date()
    const expiresAt = new Date(now.getTime() + CHECKOUT_TTL_MINUTES * 60_000)
    const beneficiaryId = await this.ensureStoreBeneficiary(
      store.id,
      mode,
      currency,
    )

    const nextAction = await this.buildNextAction(
      store.id,
      offering.account_id,
      offering.method,
    )

    // Reserved rather than pre-created so that a checkout which fails
    // before committing leaves no orphan intent behind. An orphan would
    // be counted as an open intent by the merchant dashboard forever.
    const intentId = await this.ids.reserve(PAYMENT_INTENTS_TABLE)

    const result = await this.prisma.$transaction(async (tx) => {
      const checkout = await tx.checkout.create({
        data: {
          store_id: store.id,
          mode,
          token: randomUUID().replace(/-/g, ''),
          status: 'pending_payment',
          customer_name: dto.customer_name,
          customer_email: dto.customer_email ?? null,
          customer_phone: dto.customer_phone,
          shipping_address: {
            address_line: dto.address_line,
            city: dto.city,
            notes: dto.notes ?? null,
          } as Prisma.InputJsonValue,
          currency,
          quote_total_minor: subtotalMinor,
          selected_offering_id: offering.id,
          expires_at: expiresAt,
        },
        select: { id: true, token: true },
      })

      await tx.checkoutLineItem.createMany({
        data: lines.map((l) => ({
          checkout_id: checkout.id,
          product_id: l.productId,
          variant_id: l.variantId,
          title: l.title,
          variant_title: l.variantTitle,
          image_url: l.imageUrl,
          unit_price_minor: l.unitPrice.amountMinor,
          quantity: l.quantity,
        })),
      })

      await tx.quoteComponent.create({
        data: {
          checkout_id: checkout.id,
          kind: 'line_subtotal',
          label: 'Items',
          amount_minor: subtotalMinor,
          source_ref: 'checkout.lines',
          position: 0,
        },
      })

      // Reservations are recorded and immediately converted: this phase
      // commits in one request, so stock never sits held.
      await tx.inventoryReservation.createMany({
        data: lines
          .filter((l) => l.trackInventory)
          .map((l) => ({
            checkout_id: checkout.id,
            store_id: store.id,
            mode,
            variant_id: l.variantId,
            quantity: l.quantity,
            state: 'converted' as const,
            expires_at: expiresAt,
            settled_at: now,
          })),
      })

      // Created here with the reserved id, so a checkout that fails
      // before this point leaves nothing behind.
      const intent = await tx.paymentIntent.create({
        data: {
          id: intentId,
          store_id: store.id,
          mode,
          context_kind: 'checkout',
          context_id: checkout.id.toString(),
          amount_minor: subtotalMinor,
          currency,
          capture_method: offering.capture_mode,
          usage: 'one_time',
          status: 'processing',
          offering_id: offering.id,
          account_id: offering.account_id,
          expires_at: expiresAt,
        },
        select: { id: true },
      })

      await tx.paymentAttempt.create({
        data: {
          intent_id: intent.id,
          store_id: store.id,
          mode,
          sequence: 1,
          account_id: offering.account_id,
          offering_id: offering.id,
          status: 'requires_action',
          next_action_kind: nextAction.kind,
          next_action_payload: nextAction.payload
            ? (nextAction.payload as Prisma.InputJsonValue)
            : Prisma.DbNull,
          next_action_expires_at: nextAction.payload ? expiresAt : null,
        },
      })

      const orderNumber = await this.nextOrderNumber(tx, store.id)

      const order = await tx.order.create({
        data: {
          store_id: store.id,
          order_number: orderNumber,
          status: 'PENDING',
          payment_status: 'UNPAID',
          payment_method: offering.method === 'cod' ? 'cod' : 'bank_transfer',
          currency,
          checkout_id: checkout.id,
          customer_name: dto.customer_name,
          customer_phone: dto.customer_phone,
          customer_email: dto.customer_email ?? null,
          address_line: dto.address_line,
          city: dto.city,
          notes: dto.notes ?? null,
          subtotal: toDecimalString(money(subtotalMinor, currency)),
          total: toDecimalString(money(subtotalMinor, currency)),
          items: {
            create: lines.map((l) => ({
              product_id: l.productId,
              variant_id: l.variantId,
              title: l.title,
              variant_title: l.variantTitle,
              price: toDecimalString(l.unitPrice),
              qty: l.quantity,
              image_url: l.imageUrl,
            })),
          },
        },
        select: { id: true, order_number: true },
      })

      await tx.checkout.update({
        where: { id: checkout.id },
        data: { status: 'committed', committed_at: now, order_id: order.id },
      })

      for (const line of lines) {
        if (!line.trackInventory) continue
        await tx.productVariant.update({
          where: { id: line.variantId },
          data: { inventory_qty: { decrement: line.quantity } },
        })
      }

      // Revenue is recognised at commitment; the matching receivable
      // clears when the merchant marks the order paid.
      await this.ledger.post(tx, {
        storeId: store.id,
        mode,
        currency,
        entryType: 'checkout.committed.offline',
        sourceKind: 'checkout',
        sourceId: checkout.id.toString(),
        dedupeKey: `checkout:${checkout.id}:commit`,
        occurredAt: now,
        memo: `Order ${order.order_number}`,
        postings: offlineCommitment({
          totalMinor: subtotalMinor,
          allocations: [{ beneficiaryId, amountMinor: subtotalMinor }],
        }),
      })

      await this.outbox.emit(tx, {
        storeId: store.id,
        mode,
        aggregateType: 'checkout',
        aggregateId: checkout.id.toString(),
        eventType: 'checkout.committed',
        payload: {
          checkoutId: checkout.id.toString(),
          orderId: order.id.toString(),
          orderNumber: order.order_number,
          intentId: intent.id.toString(),
          amountMinor: subtotalMinor.toString(),
          currency,
          commitmentKind: offering.commitment_kind,
        },
        occurredAt: now,
      })

      return { checkout, order }
    })

    this.logger.log(
      `Checkout committed: store ${store.id} order ${result.order.order_number} (${offering.commitment_kind})`,
    )

    return {
      order: {
        id: result.order.id.toString(),
        order_number: result.order.order_number,
        status: 'PENDING',
        payment_status: 'UNPAID',
        currency,
        total: toDecimalString(money(subtotalMinor, currency)),
      },
      checkout_token: result.checkout.token,
      // No gateway in this phase; manual methods need no redirect.
      payment_redirect_url: null,
      next_action: nextAction.payload
        ? { kind: nextAction.kind, ...nextAction.payload }
        : null,
    }
  }

  /**
   * Re-reads the instructions a customer needs after checkout.
   *
   * The success page needs this on refresh: bank details are not part of
   * the order record, they live on the attempt.
   */
  async getCheckoutStatus(slug: string, token: string) {
    const store = await this.findStore(slug)

    const checkout = await this.prisma.checkout.findFirst({
      where: { store_id: store.id, token },
    })

    if (!checkout) throw new NotFoundException('Checkout not found.')

    const intent = await this.prisma.paymentIntent.findFirst({
      where: {
        store_id: store.id,
        mode: checkout.mode,
        context_kind: 'checkout',
        context_id: checkout.id.toString(),
      },
      select: { id: true, status: true },
    })

    const attempt = intent
      ? await this.prisma.paymentAttempt.findFirst({
          where: { intent_id: intent.id },
          orderBy: { sequence: 'desc' },
          select: { next_action_kind: true, next_action_payload: true },
        })
      : null

    const order = checkout.order_id
      ? await this.prisma.order.findFirst({
          where: { id: checkout.order_id, store_id: store.id },
          select: {
            id: true,
            order_number: true,
            status: true,
            payment_status: true,
            total: true,
          },
        })
      : null

    return {
      checkout_token: checkout.token,
      checkout_status: checkout.status,
      currency: checkout.currency,
      payment_status: intent?.status ?? null,
      next_action:
        attempt && attempt.next_action_kind !== 'none'
          ? {
              kind: attempt.next_action_kind,
              ...((attempt.next_action_payload ?? {}) as Record<string, unknown>),
            }
          : null,
      order: order
        ? {
            id: order.id.toString(),
            order_number: order.order_number,
            status: order.status,
            payment_status: order.payment_status,
            total: String(order.total),
          }
        : null,
    }
  }

  /**
   * Asks the provider directly, then returns the refreshed status.
   *
   * This is what the customer's return from a gateway calls. Redirecting
   * back and then waiting for a webhook is the single most common cause
   * of "I paid but the page says it failed": the customer is often back
   * before the callback arrives. Asking synchronously removes the race.
   *
   * Safe to call repeatedly. The facts go through the same applier, so a
   * status the webhook already applied is recognised as a duplicate.
   */
  async syncCheckoutStatus(slug: string, token: string) {
    const store = await this.findStore(slug)

    const checkout = await this.prisma.checkout.findFirst({
      where: { store_id: store.id, token },
      select: { id: true, mode: true },
    })

    if (!checkout) throw new NotFoundException('Checkout not found.')

    const intent = await this.prisma.paymentIntent.findFirst({
      where: {
        store_id: store.id,
        mode: checkout.mode,
        context_kind: 'checkout',
        context_id: checkout.id.toString(),
      },
      select: { id: true, account_id: true },
    })

    if (intent?.account_id) {
      await this.pullProviderStatus(
        store.id,
        checkout.mode,
        intent.id,
        intent.account_id,
      )
    }

    return this.getCheckoutStatus(slug, token)
  }

  /**
   * Pulls status from the provider and applies whatever comes back.
   *
   * Failures are swallowed on purpose: this runs on the customer's
   * return, and a provider being slow must not turn a successful payment
   * into an error page. Reconciliation will catch up.
   */
  private async pullProviderStatus(
    storeId: bigint,
    mode: Mode,
    intentId: bigint,
    accountId: bigint,
  ): Promise<void> {
    try {
      const account = await this.prisma.paymentAccount.findFirst({
        where: { id: accountId, store_id: storeId },
        select: { id: true, gateway: true },
      })

      if (!account || !this.providers.has(account.gateway)) return

      const provider = this.providers.get(account.gateway)
      if (!provider.capabilities.statusPolling) return

      const attempt = await this.prisma.paymentAttempt.findFirst({
        where: { intent_id: intentId, store_id: storeId },
        orderBy: { sequence: 'desc' },
        select: { gateway_reference: true },
      })

      if (!attempt?.gateway_reference) return

      const credentials = await this.accounts.revealCredentialsForGateway(
        storeId,
        account.id,
      )

      const facts = await provider.fetchStatus({
        accountId: account.id,
        gatewayReference: attempt.gateway_reference,
        credentials,
        mode,
      })

      if (facts.length > 0) {
        await this.applier.applyMany(facts, 'return_url')
      }
    } catch (error) {
      this.logger.warn(
        `Status sync failed for intent ${intentId}: ${(error as Error).message}`,
      )
    }
  }

  /* ---------------------------------------------------------------- */

  /**
   * Builds the customer-facing next action for a manual method.
   *
   * Bank details are stored in the account's encrypted blob, which is
   * the only per-account storage available. They are read here and
   * copied onto the attempt so the storefront never touches the
   * credential path.
   */
  private async buildNextAction(
    storeId: bigint,
    accountId: bigint,
    method: string,
  ): Promise<{ kind: 'none' | 'bank_instructions'; payload?: Record<string, unknown> }> {
    if (method !== 'bank_transfer') return { kind: 'none' }

    const details = await this.accounts.revealCredentialsForGateway(
      storeId,
      accountId,
    )

    if (Object.keys(details).length === 0) {
      throw new BadRequestException(
        'Bank transfer is not configured for this store.',
      )
    }

    return {
      kind: 'bank_instructions',
      payload: {
        bank_name: details.bank_name ?? null,
        account_holder: details.account_holder ?? null,
        account_number: details.account_number ?? null,
        iban: details.iban ?? null,
        swift: details.swift ?? null,
        instructions: details.instructions ?? null,
      },
    }
  }

  private async findStore(slug: string) {
    const store = await this.prisma.store.findFirst({ where: { slug } })
    if (!store) throw new NotFoundException('Store not found.')
    return store
  }

  /**
   * Loads variants and recomputes prices from the database.
   * Client-supplied prices are never trusted.
   */
  private async resolveLines(
    storeId: bigint,
    currency: string,
    dto: CreateCheckoutDto,
  ): Promise<ResolvedLine[]> {
    const ids = dto.items.map((i) => BigInt(i.variant_id))

    const variants = await this.prisma.productVariant.findMany({
      where: { id: { in: ids }, product: { store_id: storeId } },
      include: { product: true },
    })

    const byId = new Map(variants.map((v: any) => [v.id.toString(), v]))
    const lines: ResolvedLine[] = []

    for (const item of dto.items) {
      const variant: any = byId.get(item.variant_id)

      if (!variant) {
        throw new BadRequestException(
          `Product variant ${item.variant_id} is unavailable.`,
        )
      }

      const priceRaw = variant.price === null ? '0' : String(variant.price)
      const unitPrice = parseDecimal(priceRaw, currency)

      if (
        variant.track_inventory &&
        !variant.continue_selling &&
        variant.inventory_qty < item.quantity
      ) {
        throw new BadRequestException(
          `Not enough stock for "${variant.product.title}".`,
        )
      }

      lines.push({
        variantId: variant.id,
        productId: variant.product_id,
        title: variant.product.title,
        variantTitle: variant.title ?? null,
        imageUrl: variant.image_url ?? null,
        unitPrice,
        quantity: item.quantity,
        trackInventory: variant.track_inventory,
        continueSelling: variant.continue_selling,
        inventoryQty: variant.inventory_qty,
      })
    }

    return lines
  }

  /** Store-scoped beneficiary, created on first use. */
  private async ensureStoreBeneficiary(
    storeId: bigint,
    mode: Mode,
    currency: string,
  ): Promise<bigint> {
    const existing = await this.prisma.beneficiary.findFirst({
      where: { store_id: storeId, mode, kind: 'store', external_ref: null },
      select: { id: true },
    })

    if (existing) return existing.id

    const created = await this.prisma.beneficiary.create({
      data: {
        store_id: storeId,
        mode,
        kind: 'store',
        external_ref: null,
        default_currency: currency,
      },
      select: { id: true },
    })

    return created.id
  }

  /**
   * Next per-store order number.
   *
   * The unique constraint on (store_id, order_number) is the real
   * guarantee; this only picks a starting point.
   */
  private async nextOrderNumber(
    tx: Prisma.TransactionClient,
    storeId: bigint,
  ): Promise<string> {
    const count = await tx.order.count({ where: { store_id: storeId } })
    return String(1000 + count + 1)
  }
}
