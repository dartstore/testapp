import { Injectable, NotFoundException } from '@nestjs/common'
import { PrismaService } from '../../prisma/prisma.service'
import { ProductStatus } from '@prisma/client'

@Injectable()
export class ProductService {
  constructor(private prisma: PrismaService) {}

  private jsonSafe(data: any) {
    return JSON.parse(JSON.stringify(data, (_, v) =>
      typeof v === 'bigint' ? v.toString() : v
    ))
  }

  private async getStore(userId: any) {
    const store = await this.prisma.store.findFirst({
      where: { ownerId: BigInt(userId) },
    })
    if (!store) throw new NotFoundException('Store not found')
    return store
  }

  private generateHandle(title: string): string {
    return title
      .toLowerCase()
      .trim()
      .replace(/[^\w\s-]/g, '')
      .replace(/\s+/g, '-')
      .replace(/-+/g, '-')
      + '-' + Date.now()
  }

  private generateVariants(options: { name: string; values: string[] }[], basePrice: number) {
    if (!options || options.length === 0) {
      return [{ title: 'Default Title', price: basePrice, option1: null, option2: null, option3: null }]
    }
    const combos: any[] = []
    const recurse = (idx: number, current: string[]) => {
      if (idx === options.length) { combos.push(current.slice()); return }
      for (const val of options[idx].values) {
        current.push(val)
        recurse(idx + 1, current)
        current.pop()
      }
    }
    recurse(0, [])
    return combos.map(combo => ({
      title: combo.join(' / '),
      price: basePrice,
      option1: combo[0] || null,
      option2: combo[1] || null,
      option3: combo[2] || null,
    }))
  }

  async getProducts(userId: any, filters: { status?: string; search?: string; page: number; limit: number }) {
    const store = await this.getStore(userId)
    const where: any = { store_id: store.id }
    if (filters.status) where.status = filters.status
    if (filters.search) {
      where.OR = [
  {
    title: {
      contains: filters.search,
      mode: 'insensitive',
    },
  },
  {
    productType: {
      name: {
        contains: filters.search,
        mode: 'insensitive',
      },
    },
  },
]
    }
    const [total, products] = await Promise.all([
      this.prisma.product.count({ where }),
      this.prisma.product.findMany({
        where,
        include: {
          productType: true,

          tags: {
            include: {
              tag: true,
            },
          },

          images: {
            orderBy: {
              position: 'asc',
            },
            take: 1,
          },

          variants: {
            orderBy: {
              position: 'asc',
            },
            take: 1,
          },

          _count: {
            select: {
              variants: true,
            },
          },
        },
        orderBy: { created_at: 'desc' },
        skip: (filters.page - 1) * filters.limit,
        take: filters.limit,
      }),
    ])
    return this.jsonSafe({ products, total, page: filters.page, pages: Math.ceil(total / filters.limit) })
  }

  async getProduct(userId: any, productId: string) {
    const store = await this.getStore(userId)
    const product = await this.prisma.product.findFirst({
      where: { id: BigInt(productId), store_id: store.id },
      include: {
  productType: true,

  tags: {
    include: {
      tag: true,
    },
  },

  images: {
    orderBy: {
      position: 'asc',
    },
  },

  variants: {
    orderBy: {
      position: 'asc',
    },
  },

  options: {
    include: {
      values: true,
    },
    orderBy: {
      position: 'asc',
    },
  },
}
    })
    if (!product) throw new NotFoundException('Product not found')
    return this.jsonSafe(product)
  }

  async createProduct(userId: any, data: any) {
    const store = await this.getStore(userId)
    const price = parseFloat(data.price || '0')
    const product = await this.prisma.product.create({
  data: {
    store_id: store.id,
    title: data.title,
    description: data.description || null,
   status: (data.status as ProductStatus) || ProductStatus.DRAFT,

    product_type_id: data.product_type_id
      ? BigInt(data.product_type_id)
      : null,

    handle: this.generateHandle(data.title),

    seo_title: data.seo_title || null,
    seo_desc: data.seo_desc || null,
  },
})

    if (data.options && data.options.length > 0) {
      for (let i = 0; i < data.options.length; i++) {
        const opt = data.options[i]
        const option = await this.prisma.productOption.create({
          data: { product_id: product.id, name: opt.name, position: i },
        })
        for (const val of opt.values) {
          if (val.trim()) {
            await this.prisma.productOptionValue.create({
              data: { option_id: option.id, value: val.trim() },
            })
          }
        }
      }
    }

    const variantData = this.generateVariants(data.options || [], price)
    for (let i = 0; i < variantData.length; i++) {
      const v = variantData[i]
      await this.prisma.productVariant.create({
        data: {
          product_id: product.id,
          title: v.title,
          price: v.price,
          compare_at_price: data.compare_at_price ? parseFloat(data.compare_at_price) : null,
          cost_per_item: data.cost_per_item ? parseFloat(data.cost_per_item) : null,
          sku: data.sku || null,
          barcode: data.barcode || null,
          inventory_qty: parseInt(data.inventory_qty || '0'),
          track_inventory: data.track_inventory !== false,
          continue_selling: data.continue_selling === true,
          option1: v.option1,
          option2: v.option2,
          option3: v.option3,
          position: i,
        },
      })
    }

    if (data.images && data.images.length > 0) {
      for (let i = 0; i < data.images.length; i++) {
        await this.prisma.productImage.create({
          data: { product_id: product.id, url: data.images[i].url, alt: data.images[i].alt || data.title, position: i },
        })
      }
    }

    if (Array.isArray(data.tag_ids) && data.tag_ids.length > 0) {
  await this.prisma.productTag.createMany({
    data: data.tag_ids.map((tagId: string | number) => ({
      product_id: product.id,
      tag_id: BigInt(tagId),
    })),
  })
}

    return this.jsonSafe(
      await this.prisma.product.findUnique({
        where: { id: product.id },
        include: { images: true, variants: true, options: { include: { values: true } } },
      })
    )
  }

  async updateProduct(userId: any, productId: string, data: any) {
    const store = await this.getStore(userId)
    const product = await this.prisma.product.findFirst({
      where: { id: BigInt(productId), store_id: store.id },
    })
    if (!product) throw new NotFoundException('Product not found')

    await this.prisma.product.update({
  where: { id: product.id },
  data: {
    title: data.title,
    description: data.description || null,

    status: data.status as ProductStatus,

    product_type_id: data.product_type_id
      ? BigInt(data.product_type_id)
      : null,

    seo_title: data.seo_title || null,
    seo_desc: data.seo_desc || null,
  },
})

  await this.prisma.productTag.deleteMany({
  where: {
    product_id: product.id,
  },
})

if (Array.isArray(data.tag_ids) && data.tag_ids.length > 0) {
  await this.prisma.productTag.createMany({
    data: data.tag_ids.map((tagId: string | number) => ({
      product_id: product.id,
      tag_id: BigInt(tagId),
    })),
  })
}

    if (data.variants) {
      for (const v of data.variants) {
        if (v.id) {
          await this.prisma.productVariant.update({
            where: { id: BigInt(v.id) },
            data: {
              price: parseFloat(v.price),
              compare_at_price: v.compare_at_price ? parseFloat(v.compare_at_price) : null,
              cost_per_item: v.cost_per_item ? parseFloat(v.cost_per_item) : null,
              sku: v.sku || null,
              barcode: v.barcode || null,
              inventory_qty: parseInt(v.inventory_qty || '0'),
              continue_selling: v.continue_selling === true,
            },
          })
        }
      }
    }

    return this.jsonSafe(
      await this.prisma.product.findUnique({
        where: { id: product.id },
        include: {

    productType:true,

    tags:{
        include:{
            tag:true
        }
    },

    images:true,

    variants:true,

    options:{
        include:{
            values:true
        }
    }

}
      })
    )
  }

  async updateProductStatus(
  userId: any,
  productId: string,
  status: ProductStatus,
) {
    const store = await this.getStore(userId)
    const product = await this.prisma.product.findFirst({
      where: { id: BigInt(productId), store_id: store.id },
    })
    if (!product) throw new NotFoundException('Product not found')
    return this.jsonSafe(
      await this.prisma.product.update({ where: { id: product.id }, data: { status } })
    )
  }

  async deleteProduct(userId: any, productId: string) {
    const store = await this.getStore(userId)
    const product = await this.prisma.product.findFirst({
      where: { id: BigInt(productId), store_id: store.id },
    })
    if (!product) throw new NotFoundException('Product not found')
    await this.prisma.productTag.deleteMany({
    where:{
        product_id:product.id
    }
})

return this.prisma.product.delete({
    where:{
        id:product.id
    }
})
  }

  async addProductImages(userId: any, productId: string, images: { url: string; alt?: string }[]) {
    const store = await this.getStore(userId)
    const product = await this.prisma.product.findFirst({
      where: { id: BigInt(productId), store_id: store.id },
    })
    if (!product) throw new NotFoundException('Product not found')
    const last = await this.prisma.productImage.findFirst({
      where: { product_id: product.id },
      orderBy: { position: 'desc' },
    })
    const created: any[] = []
    let pos = last ? last.position + 1 : 0
    for (const img of images) {
      created.push(
        await this.prisma.productImage.create({
          data: { product_id: product.id, url: img.url, alt: img.alt || null, position: pos++ },
        })
      )
    }
    return this.jsonSafe(created)
  }

  async deleteProductImage(userId: any, productId: string, imageId: string) {
    const store = await this.getStore(userId)
    const product = await this.prisma.product.findFirst({
      where: { id: BigInt(productId), store_id: store.id },
    })
    if (!product) throw new NotFoundException('Product not found')
    return this.prisma.productImage.delete({ where: { id: BigInt(imageId) } })
  }

  async getProductTypes(userId: any) {
  const store = await this.getStore(userId)

  return this.jsonSafe(
    await this.prisma.productType.findMany({
      where: {
        store_id: store.id,
      },
      orderBy: {
        name: 'asc',
      },
    }),
  )
}

async createProductType(userId: any, name: string) {
  const store = await this.getStore(userId)

  const exists = await this.prisma.productType.findFirst({
    where: {
      store_id: store.id,
      name: {
        equals: name.trim(),
        mode: 'insensitive',
      },
    },
  })

  if (exists) return this.jsonSafe(exists)

  return this.jsonSafe(
    await this.prisma.productType.create({
      data: {
        store_id: store.id,
        name: name.trim(),
      },
    }),
  )
}

async updateProductType(userId: any, id: string, name: string) {
  const store = await this.getStore(userId)

  return this.jsonSafe(
    await this.prisma.productType.update({
      where: {
        id: BigInt(id),
      },
      data: {
        name: name.trim(),
      },
    }),
  )
}

async deleteProductType(userId: any, id: string) {
  const store = await this.getStore(userId)

  const type = await this.prisma.productType.findFirst({
    where: {
      id: BigInt(id),
      store_id: store.id,
    },
  })

  if (!type)
    throw new NotFoundException('Product type not found')

  await this.prisma.product.updateMany({
    where: {
      product_type_id: type.id,
    },
    data: {
      product_type_id: null,
    },
  })

  return this.prisma.productType.delete({
    where: {
      id: type.id,
    },
  })
}
async getTags(userId: any) {
  const store = await this.getStore(userId)

  return this.jsonSafe(
    await this.prisma.tag.findMany({
      where: {
        store_id: store.id,
      },
      orderBy: {
        name: 'asc',
      },
    }),
  )
}

async createTag(userId: any, name: string) {
  const store = await this.getStore(userId)

  const exists = await this.prisma.tag.findFirst({
    where: {
      store_id: store.id,
      name: {
        equals: name.trim(),
        mode: 'insensitive',
      },
    },
  })

  if (exists) return this.jsonSafe(exists)

  return this.jsonSafe(
    await this.prisma.tag.create({
      data: {
        store_id: store.id,
        name: name.trim(),
      },
    }),
  )
}

async updateTag(userId: any, id: string, name: string) {
  const store = await this.getStore(userId)

  return this.jsonSafe(
    await this.prisma.tag.update({
      where: {
        id: BigInt(id),
      },
      data: {
        name: name.trim(),
      },
    }),
  )
}

async deleteTag(userId: any, id: string) {
  const store = await this.getStore(userId)

  const tag = await this.prisma.tag.findFirst({
    where: {
      id: BigInt(id),
      store_id: store.id,
    },
  })

  if (!tag)
    throw new NotFoundException('Tag not found')

  await this.prisma.productTag.deleteMany({
    where: {
      tag_id: tag.id,
    },
  })

  return this.prisma.tag.delete({
    where: {
      id: tag.id,
    },
  })
}

}

